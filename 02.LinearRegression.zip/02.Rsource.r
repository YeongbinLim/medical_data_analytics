#파일 -> 작업 디렉토리 변경 -> 파일 경로 선택

#현재 working directory 얻기
getwd()
#setwd("D:/Data/01/") #set working directory. 경로를 직접 입력해주어 작업 디렉토리 이동
#현재 폴더에 파일 목록 확인
dir()

#조건문과 반복문

#sample: 첫번째 매개변수 1~6 사이의 숫자를 100개 생성한다. replace=T는 중복 허용을 의미
DiceA <- sample( 1:6, 1000, replace=T)
DiceB <- sample( 1:6, 1000, replace=T)

#명목형 변수 (Categorical variable) 이므로, table로 count를 확인
table(DiceA)
table(DiceB)

#명목형 변수의 count를 barplot으로 시각화 하기
barplot(table(DiceA))
barplot(table(DiceB))

# 데이터를 요약하여 정보를 보여주는 summary 함수
summary(DiceA)
summary(DiceB)

#DiceA와 DiceB를 합친 Data.frame을 생성한다.
Dice <- data.frame(DiceA, DiceB)

Dice[1,]
Dice[,1]
Dice[1:5,]
Dice[ c(1, 3, 5, 7),]


######조건문
head(Dice)
Dice[1,1] > Dice[1,2]
Dice[1,1] < Dice[1,2]
Dice[1,1] == Dice[1,2]

#if 안의 값이 참(TRUE)이면 {} 안의 코드를 실행한다.
if(TRUE){
	print("TRUE 입니다.")
}
if(FALSE){
	print("FALSE 입니다.")
}

#if 다음의 실행할 코드가 한줄이면 {}을 쓰지 않아도 된다.
if(Dice[1,1] > Dice[1,2]) print("첫번째 주사위는 DiceA가 큽니다.")
if(Dice[1,1] < Dice[1,2]) print("첫번째 주사위는 DiceB가 큽니다.")
if(Dice[1,1] == Dice[1,2]) print("첫번째 주사위는 DiceA와 DiceB가 같습니다.")

######반복문
#i를 1부터 10까지 증가시키면서 안의 코드를 실행한다.
for(i in 1:10){
	print(i)
}

for(i in 30:20){
	print(i)
}

for(i in c(1, 3, 5, 7) ){
	print(i)
}

#행과 열의 index에 i라는 변수를 활용하여 출력하기
i = 1
if(Dice[i,1] > Dice[i,2]) print("첫번째 주사위는 DiceA가 큽니다.")
if(Dice[i,1] < Dice[i,2]) print("첫번째 주사위는 DiceB가 큽니다.")
if(Dice[i,1] == Dice[i,2]) print("첫번째 주사위는 DiceA와 DiceB가 같습니다.")

i = 2
if(Dice[i,1] > Dice[i,2]) print("두번째 주사위는 DiceA가 큽니다.")
if(Dice[i,1] < Dice[i,2]) print("두번째 주사위는 DiceB가 큽니다.")
if(Dice[i,1] == Dice[i,2]) print("두번째 주사위는 DiceA와 DiceB가 같습니다.")

#Matrix 데이터의 경우 행과 열의 수는 nrow, ncol 함수로 사용 가능하다.
nrow(Dice) #행 (row, sample)의 수
ncol(Dice) #열 (column)의 수

#반복문을 활용하여 출력하기
for(i in 1:nrow(Dice)){ # 1:nrow(Dice) 혹은 1:1000
	if(Dice[i,1] > Dice[i,2]) print("DiceA가 큽니다.")
	if(Dice[i,1] < Dice[i,2]) print("DiceB가 큽니다.")
	if(Dice[i,1] == Dice[i,2]) print("DiceA와 DiceB가 같습니다.")	
}

Wins <- c(0, 0, 0) # DiceA 승리수, DiceB 승리수, 동점
for(i in 1:nrow(Dice)){
	if(Dice[i,1] > Dice[i,2]) Wins[1] = Wins[1] +1
	if(Dice[i,1] < Dice[i,2]) Wins[2] = Wins[2] +1
	if(Dice[i,1] == Dice[i,2]) Wins[3] = Wins[3] +1
}

#DiceA, DiceB, 동점 각각의 수 확인해보기
print(Wins)

#배열을 비교함으로써 반복문을 대체할 수 있다.
Dice[,1] > Dice[,2]
Dice[,1] < Dice[,2]
Dice[,1] == Dice[,2]

sum(Dice[,1] > Dice[,2]) #DiceA 승리 수
sum(Dice[,1] < Dice[,2]) #DiceB 승리 수
sum(Dice[,1] == Dice[,2]) #동점의 수



family <- read.table("02.Heights.txt", header=T)

# head: 상단 6개의 row에 대한 데이터를 확인한다.
head(family)

# str (Structure): 데이터의 구조를 확인한다.
str(family)

# column의 이름을 확인한다.
colnames(family)

# 각 데이터 파일의 row, column의 수 확인하기
# row의 수는 샘플의 수를 뜻한다.
dim(family)


# 3D scatter plot
install.packages("scatterplot3d") # "scatterplot3d" 라이브러리를 설치한다.
library(scatterplot3d) # scatterplot3d 라이브러리를 호출한다.

#가족 데이터에서 필요한 3가지 변수, father, mother, height만 추출
family <- data.frame("father"=family$father, "mother"=family$mother, "height"=family$height)
#혹은 family <- family[, c(2,3,5)] 로 간단하게 해결 가능
head(family)
family <- family*2.54 #inch - cm 변환
head(family)


# 아버지의 키와 아이 키를 2차원 scatter plot으로 시각화
plot(x=family$father, y=family$height)
# 어머니의 키와 아이 키를 2차원 scatter plot으로 시각화
plot(x=family$mother, y=family$height)


# 아버지의 키를 독립변수로, 아들의 키를 종속변수로 하여 선형회귀 방정식을 구한다.
# 아버지의 키와 아이 키를 2차원 scatter plot으로 시각화
plot(x=family$father, y=family$height)
# 아들의 키를 종속변수로, 아버지의 키를 독립변수로 선형방정식 도출
result <- lm(family$height ~ family$father)
result <- lm(height ~ father, data=family)

# 선형회귀 결과로 얻은 선형방정식 결과를 상세히 report
result

summary(result)
# 2차원 scatter plot에 아들의 키와 아버지의 키를 이용하여 도출된 선형방정식을 시각화
plot(x=family$father, y=family$height)
abline(result, col="red", lwd=2)


# 어머니의 키를 독립변수로, 아들의 키를 종속변수로 하여 선형회귀 방정식을 구한다.
# 어머니의 키와 아이 키를 2차원 scatter plot으로 시각화
plot(x=family$mother, y=family$height)
# 아들의 키를 종속변수로, 어머니의 키를 독립변수로 선형방정식 도출
result <- lm(height ~ mother, data=family)

# 선형방정식 결과를 상세히 report
summary(result)
# 2차원 scatter plot에 아들의 키와 어머니의 키를 이용하여 도출된 선형방정식을 시각화
abline(result, col="red", lwd=2)


## Multiple regression
result <- lm(height ~ mother + father, data=family)
result
summary(result)

#family 데이터를 이용하여 3차원 좌표에 데이터를 시각화한다.
s3d <- scatterplot3d(family, type = "h", color = "blue", angle=55, pch = 16)

#다중회귀 분석법을 이용하여 아이의 키에 대한 방정식을 구한다.
result <- lm(height ~ mother + father, data=family)

# 구해진 2차원 방정식을 3차원 좌표에 면으로 시각화 한다.
s3d$plane3d(result)
# Add supplementary points


#실제 데이터를 이용하여 회귀 방정식의 성능 평가
testData <- read.table("02.Heights_test.txt", header=T)
testData <- data.frame("father"=testData$father, "mother"=testData$mother, "height"=testData$height)
testData <- testData * 2.54
#회귀방정식을 활용하여 예측값 구하기
predicted <- 0.41061 * testData$father + 0.33293 * testData$mother + 49.5992736
predict(result, testData)

#예측값과 실제값의 분포를 시각화 하기
#xlim과 ylim은 x축의 범위, y축의 범위를 뜻한다.
plot(x=testData$height, predicted, xlim=c(168, 180), ylim=c(168, 180))

#예측값과 실제값의 차이 구하기
Error <- testData$height - predicted
print(Error)

#Error의 lineplot 그리기
plot(Error, ylim=c(-7, 7), xlim=c(0, 8), pch=16, cex=2,
	 col="skyblue1", xlab="Children", ylab="Erorr of height")
#ylim ,xlim: 그래프에서 y, x축의 범위
#pch: point의 타입
#cex: point의 크기
#xlab, ylab: 그래프에서 x, y축의 이름

abline(h=0, lwd=2)
lines(Error, lwd=2, col="blue")
text(x=1:7, y=Error-0.5, labels=round(Error,3))


#MSE: Mean squared error 평균 제곱근 오차. 선형회귀 방정식의 성능을 평가하는 척도
MSE = mean(Error^2)

print(MSE)

#Pearson correlation 피어슨 상관분석
#아들의 키와 아버지의 키에 대한 상관계수 구하기
cor.test(family$height, family$father)
#아들의 키와 어머니의 키에 대한 상관계수 구하기
cor.test(family$height, family$mother)
#아버지와 어머니의 상관계수 구하기
cor.test(family$father, family$mother)


#correlation plot 그리기
install.packages("corrplot")
library(corrplot)

cor(family)

corr <- cor(family)
corrplot( corr, method="circle")
corrplot( corr, method="pie")
corrplot( corr, method="color")
corrplot( corr, method="number")

# 다양한 매개변수 확인하기 ?corrplot
corrplot( corr, method="color", type="upper", addCoef.col="black" )