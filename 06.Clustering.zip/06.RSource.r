# 2차원 변수 5개 생성하기.
x1 <- c(1, 2)
x2 <- c(1, 3)
x3 <- c(3, 6)
x4 <- c(4, 7)
x5 <- c(1, 5)

# x라는 변수로 5개의 2차원 변수를 data.frame으로 묶기
x <- t(data.frame(x1, x2, x3, x4, x5))

#데이터들을 시각화 한다.
plot(x, lwd=2, pch=16, cex=2 , ylim=c(1, 8), xlim=c(0, 5) )
#lwd 원을 그리는 선의 두깨 = 2
#pch 16 = 색칠된 point
#cex point의 크기
#xlim, ylim은 그려지는 그래프의 x, y축의 range

text(x-0.2, labels=paste0("x",1:5))
#point 좌표에서 x, y축으로 0.2씩 떨어진 위치에 x1, x2 ~ x5 text를 그린다.


#distance 구하는 함수.
#method에 따라서 distance 값의 결과는 달라진다.
#일반적으로 euclidean을 가장 많이 쓰지만, 실습에서는 4가지 모두 사용한다.
eucl <- dist(x, method="euclidean")
manh <- dist(x, method="manhattan")
maxi <- dist(x, method="maximum")
mink <- dist(x, method="minkowski")

#그룹간의 distance는 centroid를 이용하여 계층적 군집 분석을 시행한다.
eucl_hc <- hclust(eucl, method="centroid")
manh_hc <- hclust(manh, method="centroid")
maxi_hc <- hclust(maxi, method="centroid")
mink_hc <- hclust(mink, method="centroid")

#2 by 2, 4개의 그림을 한번에 띄우도록 하는 함수
par( mfrow = c(2, 2) )

# 4가지 종류의 distance 메소드를 통해 생성된 계층적 군집 분석 결과를 시각화 한다.
plot(eucl_hc, main="euclidean")
plot(manh_hc, main="manhattan")
plot(maxi_hc, main="maximum")
plot(mink_hc, main="minkowski")

groups <- cutree(eucl_hc, k=2)


############## Glioblastoma RNASeq data 분석
 
library(ConsensusClusterPlus)
 
#RNA Expression data 읽기
rnaseq <- read.table("06.Glioblastoma_RNASeq.txt", header=T, stringsAsFactors=F, sep="\t")

#Clinical data 읽기
clinical <- read.table("06.Glioblastoma_Clinical.txt", header=T, stringsAsFactors=F, sep="\t")

#데이터 구조 확인하기
head(rnaseq)
head(clinical)
str(clinical)

#mad: Median Absolute Deviation
#편차가 큰 유전자 5000개를 대상으로 분석
mads = apply(rnaseq, 1, mad)
rnaseq <- rnaseq[rev(order(mads))[1:5000],]
rnaseq <- sweep(rnaseq,1, apply(rnaseq,1,median,na.rm=T))

#ConsensusClusterPlus 함수에서 RNA Expression data를 matrix 형태로 받기 때문에 형변환
rnaseq <- as.matrix(rnaseq)

#Consensus Clustering 실행
results = ConsensusClusterPlus(rnaseq,maxK=6,reps=50,pItem=0.8,pFeature=1,
	clusterAlg="hc",distance="pearson",seed=1262118388.71279,plot="png")
#k=2부터 6까지 모두 시행
#사람과 사람의 distance는 1-pearson correlation로 설정

#k에 따라 환자들이 그룹으로 나누어진 결과
table(results[[2]]$consensusClass)
table(results[[3]]$consensusClass)
table(results[[4]]$consensusClass)


#Survival 분석을 위한 clinical data 정제

#생존 데이터는 최종 follow up과 사망 날짜가 따로 있기 때문에
#사망한 환자는 사망날짜로, 생존한 환자는 최종 follow up
Time <- clinical$death_days_to
Alive_idx <- clinical$vital_status == "Alive"
Time[ Alive_idx ] <- clinical$last_contact_days_to[ Alive_idx ]
Status <- clinical$vital_status


#클러스터링 결과에 따라 생존에도 차이가 나는지 검정하기 위한 코드

#k=2인 클러스터링 결과를 활용한 데이터 분석
fit <- survfit(Surv(Time, Status == "Dead") ~ results[[2]]$consensusClass)
plot(fit, col=1:2, xlab="Time days", ylab="Survival probability", lwd=2, mark.time=T)
legend("topright", legend=c("group1", "group2"), col=1:2, lwd=2)

res <- coxph( Surv(Time, Status=="Dead") ~ factor(results[[2]]$consensusClass) )
summary(res)

#k=3인 클러스터링 결과를 활용한 데이터 분석
fit <- survfit(Surv(Time, Status == "Dead") ~ results[[3]]$consensusClass)
plot(fit, col=1:3, xlab="Time days", ylab="Survival probability", lwd=2, mark.time=T)
legend("topright", legend=c("group1", "group2", "group3"), col=1:3, lwd=2)

res <- coxph( Surv(Time, Status=="Dead") ~ factor(results[[3]]$consensusClass) )
summary(res)

#k=4인 클러스터링 결과를 활용한 데이터 분석
fit <- survfit(Surv(Time, Status == "Dead") ~ results[[4]]$consensusClass)
plot(fit, col=1:4, xlab="Time days", ylab="Survival probability", lwd=2, mark.time=T)
legend("topright", legend=c("group1", "group2", "group3" ,"group4"), col=1:4, lwd=2)

res <- coxph( Surv(Time, Status=="Dead") ~ factor(results[[4]]$consensusClass) )
summary(res)
