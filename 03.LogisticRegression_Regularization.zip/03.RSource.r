#파일 -> 작업 디렉토리 변경 -> 파일 경로 선택

#현재 working directory 얻기
getwd()
#setwd("D:/Data/01/") #set working directory. 경로를 직접 입력해주어 작업 디렉토리 이동
#현재 폴더에 파일 목록 확인
dir()



#Data types
print("안녕하세요")
print(안녕하세요) #Error

print(1)
print("1")

print(1<3)
print("1<3")

print(2 + 1)
print("2" + 1) #Error

#문자열과 정수의 형변환
as.numeric("2") + 2

print("2" + "2") #Error. 문자열간의 덧셈은 불가능.
paste("2", "2", sep="") #sep 매개변수는 두 문자열을 붙일 때, 문자 사이에 들어가는 것을 담는다.
paste("2", "2", sep=":")

#숫자와 문자열을 합쳐 문장을 구성하는 방법 paste
paste("나는 ", 2,"학년이다,", sep="")

#Data.frame 데이터 붙이기 rbind(), cbind()

Student1 <- sample( 1:100, 5, replace=T) # 1~100 사이 값을 5개 추출한다. replace=T는 중복추출을 허용
Student2 <- sample( 1:100, 5, replace=T) # 1~100 사이 값을 5개 추출한다. replace=T는 중복추출을 허용
Student3 <- sample( 1:100, 5, replace=T) # 1~100 사이 값을 5개 추출한다. replace=T는 중복추출을 허용

Student <- rbind(Student1, Student2, Student3) #학생 3명의 데이터 합치기 (Row bind)
colnames(Student) <- c("언어", "수리", "외국어", "사회", "과학")

#rownames와 colnames
colnames(Student)
rownames(Student)

colnames(Student)[1]
colnames(Student)[2]
colnames(Student)[5]

rownames(Student)[1]
rownames(Student)[3]

#학생별 평균내기 (Row-wise mean)
for(i in 1:nrow(Student)){
	print( rownames(Student)[i] )
	print(mean(Student[i,]))
}

#과목별 평균내기 (Column-wise mean)
for(i in 1:ncol(Student)){
	print( colnames(Student)[i] )
	print(mean(Student[,i]))
}



#Student1 학급과 Student2 학급 데이터를 생성하여 t.test 실험하기

#rnorm : 정규분포 데이터 만들기. (평균을 중심으로 표준편차만큼 떨어져있는 분포)
Korean <- rnorm(100, 50, 10) #100명, 평균 50, 표준편차 10
English <- rnorm(100, 60, 12) #100명, 평균 60, 표준편차 12
Math <- rnorm(100, 40, 15) #100명, 평균 40, 표준편차 15
Student1 <- data.frame(Korean, English, Math)

Korean <- rnorm(150, 70, 10) #150명, 평균 70, 표준편차 10
English <- rnorm(150, 70, 12) #150명, 평균 70, 표준편차 12
Math <- rnorm(150, 40, 13) #150명, 평균 40, 표준편차 13
Student2 <- data.frame(Korean, English, Math)

head(Student1) #상단 6개의 데이터
head(Student2, 10) #상단 10개의 데이터

tail(Student1) #하단 6개의 데이터
tail(Student2, 10) #하단 10개의 데이터

#학생 추가하기
Student1 <- rbind(Student1, c(100, 90, 80) ) #국영수 각각 100, 90, 80 점의 학생 추가하기

#학생별 평균내기
#rowSums
average1 <- rowSums(Student1) / ncol(Student1)
average2 <- rowSums(Student2) / ncol(Student2)

boxplot(average1, average2)

#각 과목별 Student1과 Student2의 차이를 보는 t.test
res1 <- t.test(Student1$Korean, Student2$Korean )
res2 <- t.test(Student1$English, Student2$English )
res3 <- t.test(Student1$Math, Student2$Math )

#t.test 결과로 나오는 변수 역시 
res1$p.value
res2$p.value
res3$p.value

#List 문법 익히기
res <- c()
res[1] <- t.test(Student1$Korean, Student2$Korean )
res[2] <- t.test(Student1$English, Student2$English )
res[3] <- t.test(Student1$Math, Student2$Math )
#Error. vector 배열엔 하나의 정보만 넣을 수 있기 때문에, 여러개의 변수가 묶여있는 데이터는 넣을 수 없음

res <- list()
res[[1]] <- t.test(Student1$Korean, Student2$Korean )
res[[2]] <- t.test(Student1$English, Student2$English )
res[[3]] <- t.test(Student1$Math, Student2$Math )

res[[1]]$p.value
res[[2]]$estimate

#for loop로 모든 과목에 대해 t.test 한 결과를 List로 저장하기
res <- list()
for(i in 1:3){
	res[[i]] <- t.test(Student1[,i], Student2[,i])
}

res[[1]]$p.value
res[[2]]$estimate



# Logistic Regression
x <- seq(-3, 3, by=0.2)
alpha = 1.1
beta = 1.5
y = exp(alpha + beta*x) / (1 + exp(alpha + beta*x))
plot(x,y, type="b")

#데이터 읽기
Data <- read.table("03.SurvivalLogistic.txt", header=T)

head(Data)
colnames(Data)
str(Data)

summary(Data)

#Logistic regression 분석하기. Generalized linear model
model <- glm(outcome == "dead" ~.,family=binomial(link='logit'),data=Data)
#각 변수의 Coefficient 확인하기
coef(model)
confint(model)

step(model, direction="both")

#유의한 변수만 뽑아서 
model <- glm(outcome=="dead" ~ age + smstat	+ hichol + highbp, family=binomial, data=Data)

#각 변수의 Coefficient 확인하기
coef(model)
confint(model)

#Coefficients의 실제 Odds ratio를 알기 위해선 Exponential이 필요하다.
Coefficients <- cbind(coef(model), confint(model))
exp( Coefficients )

#ROC Curve 구하기
install.packages("ROCR")
library(ROCR)

#Logistic regression 구성에 사용된 데이터를 그대로 적용하여 값 얻기
p <- predict(model, newdata=Data, type="response")
#생존, 사망을 숫자로 표현하기
cols <- as.numeric(Data$outcome == "dead") + 1

#Scatter plot과 boxplot을 이용햔 결과 확인하기
plot(p, col = cols, pch=16)
boxplot(p ~ cols)

#ROC Curve를 구하기 위한 과정
pr <- prediction(p, Data$outcome == "dead")
prf <- performance(pr, measure = "tpr", x.measure = "fpr")

auc_ROCR <- performance(pr, measure = "auc")
auc_ROCR <- round(auc_ROCR@y.values[[1]], 3)

plot(prf, colorize = T, main=paste0("ROC curve. AUC: ",auc_ROCR))
abline(a = 0, b = 1)

par(mfrow=c(2,2))
plot(model)


#Ridge regression & Lasso regression & ElasticNet regression
install.packages("glmnet")
library(glmnet)

#종속변수 생성
variableY <- as.numeric(Data$outcome == "dead")

#독립변수 matrix 생성
variableX <- sapply(Data[,2:10], as.numeric)
class(variableX) <- "numeric"

#Ridge regression
#Lambda값에 의해 regularization 되면서 줄어드는 각 변수의 coefficient를 주의.
model_ridge <- glmnet(y=variableY, x=variableX, family="binomial", alpha=0)
plot(model_ridge)

#Cross validation으로 AUC 성능평가 확인하기
model_ridge_cv <- cv.glmnet(y=variableY, x=variableX, family="binomial", alpha=0, type.measure="auc")
plot(model_ridge_cv)

#Ridge regression에서 가장 좋은 모델인 lambda.min과 lambda.1se 2가지의 lambda를 활용한 regression 모델 결과 보기
#lambda min은 Cross-validation model에서 가장 낮은 오류율을 가지는 lambda.
#Lambda 1se는 lambda-min보다는 단순하지만, 1표준오차 내에서 최고의 모델
opt.lam_ridge = c(model_ridge_cv$lambda.min, model_ridge_cv$lambda.1se)
coef(model_ridge_cv, s = opt.lam_ridge) #Ridge regression
coef(model) #logistic regression

cbind(coef(model_ridge_cv, s = opt.lam_ridge), coef(model))



#Lasso regression
#Lambda값에 의해 regularization 되면서 줄어드는 각 변수의 coefficient를 주의
model_lasso <- glmnet(y=variableY, x=variableX, family="binomial", alpha=1)
plot(model_lasso)

#Cross validation으로 AUC 성능평가 확인하기
model_lasso_cv <- cv.glmnet(y=variableY, x=variableX, family="binomial", alpha=1, type.measure="auc")
plot(model_lasso_cv)

#Lasso regression에서 가장 좋은 모델인 lambda.min과 lambda.1se 2가지의 lambda를 활용한 regression 모델 결과 보기
opt.lam_lasso = c(model_lasso_cv$lambda.min, model_lasso_cv$lambda.1se)

coef(model_lasso_cv, s = opt.lam_lasso) #Ridge regression
coef(model) #logistic regression

Coefficients <- cbind(coef(model_ridge_cv, s = opt.lam), coef(model_lasso_cv, s = opt.lam), coef(model))
colnames(Coefficients) <- c("Ridge_lambda.min", "Ridge_lambda.1se", "lasso_lambda.min", "lasso_lambda.1se", "LogisticRegression")

#Ridge, Lasso, Logistic regression에 의해 도출된 coefficients 보기
print(Coefficients)

model <- glmnet(y=variableY, x=variableX, family="binomial", alpha=1)
plot(model)



#Lasso regression 결과 보기

newData <- read.table("03.SurvivalLogistic_test.txt", header=T)

variableY_new <- as.numeric(newData$outcome == "dead")
variableX_new <- sapply(newData[,2:10], as.numeric)
class(variableX_new) <- "numeric"

 
result <- predict(model_lasso_cv, newx = variableX_new, s = "lambda.min", type = "class")
resultData <- data.frame(result, variableY_new)
colnames(resultData) <- c("Predicted", "Survival")

print(resultData)

#contingencyTable 만들기.
contingencyTable <- table(resultData)
print(contingencyTable)

#순서 바꾸기. 좌측이 event 발생 (사망), 우측이 생존
contingencyTable <- contingencyTable[c(2,1), c(2,1)]
print(contingencyTable)

Accuracy <- (contingencyTable[1,1] + contingencyTable[2,2]) / sum(contingencyTable) * 100
Sensitivity <- contingencyTable[1,1] / sum(contingencyTable[,1]) * 100
Specificity <- contingencyTable[2,2] / sum(contingencyTable[,2]) * 100

#결과 출력하기
print( paste("Accuracy는 ", Accuracy, "%입니다."), sep="")
print( paste("Sensitivity는 ", Sensitivity, "%입니다."), sep="")
print( paste("Specificity는 ", Specificity, "%입니다."), sep="")