#파일 -> 작업 디렉토리 변경 -> 파일 경로 선택

#현재 working directory 얻기
getwd()
#setwd("D:/Data/01/") #set working directory. 경로를 직접 입력해주어 작업 디렉토리 이동
#현재 폴더에 파일 목록 확인
dir()


#R의 기본 Numeric data의 연산
1+1
3*5

#Combine c() 함수. 데이터 벡터를 생성
c(1, 2, 3)
c(1:3)
c(1, 2, 3) + 3
c(1, 2, 3) + c(1, 1, 3)
c(1, 2, 3) * 5
c(1, 2, 3) * c(1, 2, 3)

#데이터 벡터의 연산은 같은 길이에 대해서만 가능
c(1, 2, 3) + c(1, 2)
c(1, 2, 3) * c(1, 2)

#변수에 벡터 데이터 저장하기
DiceA <- c(1, 3, 5)
DiceB <- c(2, 2, 4)

#벡터 변수 출력하기
print(DiceA)
print(DiceB)

#벡터 변수 연산
DiceA + DiceB

#데이터 프레임 생성하기.
Dice <- data.frame(DiceA, DiceB)
print(Dice)

#1행 출력하기
Dice[1,]

#1열 출력하기
Dice[,1]
Dice[,"DiceA"]



################################
#서울과 인천의 키/몸무게 데이터를 활용한 기본 통계분석

#read.table 파일을 읽어 변수에 저장
bmi1 <- read.table("01.bmi_seoul.txt", header=T)
bmi2 <- read.table("01.bmi_incheon.txt", header=T)


# head: 상단 6개의 row에 대한 데이터를 확인한다.
head(bmi1)
head(bmi2)

# str (Structure): 데이터의 구조를 확인한다.
str(bmi1)
str(bmi2)

# column의 이름을 확인한다.
colnames(bmi1)
colnames(bmi2)

# 각 데이터 파일의 row, column의 수 확인하기
# row의 수는 샘플의 수를 뜻한다.
dim(bmi1)
dim(bmi2)

#1번째 행의 데이터를 출력
bmi1[1,]
bmi2[1,]

#1번째 열의 데이터를 출력
bmi1[,1]
bmi2[,1]

#1번째 열의 데이터인 height를 출력
bmi1$height
bmi2$height

bmi1[,"height"]
bmi2[,"height"]

# bmi1 데이터의 column에 대한 정보를 확인한다.
bmi1$height
bmi1$weight
bmi1$bmi
bmi1$class

# bmi1 데이터의 평균과 표준편차를 확인한다.
mean(bmi1$height)
mean(bmi1$weight)
mean(bmi1$bmi)

sd(bmi1$height)
sd(bmi1$weight)
sd(bmi1$bmi)

# bmi2 데이터의 평균과 표준편차를 확인한다.
mean(bmi2$height)
mean(bmi2$weight)
mean(bmi2$bmi)

sd(bmi2$height)
sd(bmi2$weight)
sd(bmi2$bmi)


# 유의수준 0.05를 기준으로 하였을 때, p.value가 0.05 이하이면 평균은 차이가 있다.
# 유의수준 0.05를 기준으로 하였을 때, p.value가 0.05 이상이면 평균은 차이가 없다.

# boxplot으로 두 데이터의 분포를 시각화 한다.
# ?boxplot을 통해 다양한 매개변수 확인
boxplot(bmi1$height, bmi2$height)
boxplot(bmi1$weight, bmi2$weight)

# boxplot으로 각 데이터별 height와 weight의 분포를 한눈에 확인한다.
# ?plot을 통해 다양한 매개변수 확인
plot(x = bmi1$height, y=bmi1$weight)
plot(x = bmi2$height, y=bmi2$weight)

# 히스토그램 그리기
# ?hist를 통해 다양한 매개변수 확인
hist(bmi1$weight)
hist(bmi2$weight)

#도수를 세분화한 히스토그램 그리기
hist(bmi1$weight, breaks=20)
hist(bmi2$weight, breaks=20)

#class 데이터의 count 세기
table(bmi1$class)
table(bmi2$class)

#class 데이터 barplot 그리기
# ?barplot을 통해 다양한 매개변수 확인
barplot(table(bmi1$class))
barplot(table(bmi2$class))


# bmi1과 bmi2의 키, 몸무게, bmi에 대해 평균을 검정한다.
# t test는 연속형 변수를 검정하기 위한 통계분석 방법
t.test(bmi1$height, bmi2$height)
t.test(bmi1$weight, bmi2$weight)
t.test(bmi1$bmi, bmi2$bmi)

# t.test의 결과를 변수에 저장한다.
result <- t.test(bmi1$weight, bmi2$weight)

#result라는 변수에 t.test의 결과가 저장되며, $ 키워드를 이용하여 어떤 변수를 가졌는지, 어떻게 변수를 접근하는지 알 수 있다.
#> result$ #+tab
#result$statistic   result$parameter   result$p.value     result$conf.int    
#result$estimate    result$null.value  result$alternative result$method      
#result$data.name  

#?t.test

#fisher 검정. fisher 검정은 범주형 변수에 대한 통계분석 방법
fisher.test(bmi1$class, bmi2$class)