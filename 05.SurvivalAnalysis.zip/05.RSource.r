#파일 -> 작업 디렉토리 변경 -> 파일 경로 선택

#현재 폴더에 파일 목록 확인
dir()

install.packages("survival")
library(survival)

# 데이터 읽기
melanoma <- read.table("05.SurvivalAnalysisMelanom.txt", header=T)

# head: 상단 6개의 row에 대한 데이터를 확인한다.
head(melanoma)

# str (Structure): 데이터의 구조를 확인한다.
str(melanoma)

# column의 이름을 확인한다.
colnames(melanoma)

# 각 데이터 파일의 row, column의 수 확인하기
# row의 수는 샘플의 수를 뜻한다.
dim(melanoma)


# 각 데이터 변수의 출력
melanoma$No
melanoma$Status
melanoma$Days
melanoma$Ulceration
melanoma$TumorSize
melanoma$Gender

# attach 함수를 통해, Data frame 안에 속한 변수들을 바로 접근할 수 있도록 한다.
attach(melanoma)

No
Status
Days
Ulceration
TumorSize
Gender


# 생존 변수을 결합한 객체 만들기
Surv(Days, Status==1)

# 성별에 따른 생존분포
fit <- survfit( Surv(Days, Status==1) ~ Gender)

# 성별에 따른 Kaplan meier graph
plot(fit)
plot(fit,
	 col=c("red","blue"), # 색 지정. 빨강 파랑
	 mark.time=T, # Censored 데이터의 경우 체크바 표시
	 xlab="Time (days)", # X축 이름 표시
	 ylab="Survival probability", # Y축 이름 표시
	 lwd=2) # 선 굵기 2

# 데이터 정보 표시
legend("topright", # 우측 상단에 정보 표시
		legend=c("Female", "Male"), # 1 = Female, 2 = Male
		col=c("red", "blue"), lwd=2) # 색은 빨강/파랑, 선 굵기 = 2

		
# Log Rank Test 분석하기
#성별에 따른 Log Rank Test
survdiff( Surv(Days, Status==1) ~ Gender)

#궤양에 따른 Log Rank Test
survdiff( Surv(Days, Status==1) ~ Ulceration)


#궤양 유무에 따른 Kaplan meier graph
fit <- survfit( Surv(Days, Status==1) ~ Ulceration)
plot(fit,
	 col=c("red","blue"), # 색 지정. 빨강 파랑
	 mark.time=T, # Censored 데이터의 경우 체크바 표시
	 xlab="Time (days)", # X축 이름 표시
	 ylab="Survival probability", # Y축 이름 표시
	 lwd=2) # 선 굵기 2

# 데이터 정보 표시
legend("topright", # 우측 상단에 정보 표시
		legend=c("Ulceration", "Non-Ulceration"), # 1 = Female, 2 = Male
		col=c("red", "blue"), lwd=2) # 색은 빨강/파랑, 선 굵기 = 2


#Cox regression analysis
#성별에 따른 coxph regression 분석
#변수가 하나인 경우, univariate coxph regression
coxResult <- coxph( Surv(Days, Status==1) ~ Gender )
summary(coxResult)

#다변량 coxph regression
#변수가 다수인 경우, univariate coxph regression
coxResult <- coxph( Surv(Days, Status==1) ~ Ulceration + TumorSize + Gender )
summary(coxResult)

#1/100 mm 단위인  TumorSize를 mm 단위로 만들어주어 해석하기 용이하게 함.
TumorSize_mm <- TumorSize / 100
coxResult <- coxph( Surv(Days, Status==1) ~ Ulceration + TumorSize_mm + Gender )
summary(coxResult)












##############
# Ovarian Cancer (난소암) 환자의 BRCA 돌연변이 유전자에 대한 생존분석

#Ovarian Cancer, 난소암 환자들의 임상데이터 및 유전자 돌연변이 데이터 추출
Clinical <- read.table("05.OvarianCancerPatients_ClinicalData.txt", header=T, sep="\t", stringsAsFactors=F)
Mutation <- read.table("05.OvarianCancerVariants.txt", header=T, sep="\t", stringsAsFactors=F)

#데이터의 구조 보기
str(Clinical)
str(Mutation)

#원하는 데이터 추출하기
Patient <- Clinical$PATIENT_BARCODE
Time <- Clinical$OS_MONTHS
Status <- Clinical$OS_STATUS


#Mutation data에서 BRCA1에 해당하는 돌연변이를 가진 환자 목록 가져오기
BRCA1_idx <- Mutation$gene_symbol == "BRCA1"
BRCA1_patient <- Mutation$case_id[BRCA1_idx]

#Mutation data에서 BRCA2에 해당하는 돌연변이를 가진 환자 목록 가져오기
BRCA2_idx <- Mutation$gene_symbol == "BRCA2"
BRCA2_patient <- Mutation$case_id[BRCA2_idx]

#BRCA1이란 변수에는 BRCA1 mutation을 가진 환자들은 TURE, BRCA1 Mutation이 없는 환자들은 FALSE가 들어가는 Factor형 데이터가 된다.
BRCA1 <- Patient %in% BRCA1_patient
BRCA2 <- Patient %in% BRCA2_patient

#임상변수와 BRCA 돌연변이 데이터를 모두 포함하는 Data.frame 생성하기
Data <- data.frame(Patient, Time, Status, BRCA1, BRCA2)
head(Data)


# BRCA1 유전자 돌연변이에 따른 생존분석
# Log Rank Test
survdiff( Surv(Time, Status=="DECEASED") ~ BRCA1, data=Data)

# Cox Proportional Hazard Ratio Model
res <- coxph(Surv(Time, Status=="DECEASED") ~ BRCA1, data=Data)
summary(res)

# BRCA1 돌연변이 유무에 따른 Kaplan Meier Graph
fit <- survfit(Surv(Time, Status=="DECEASED") ~ BRCA1, data=Data)
plot(fit, col=c("black","red"), xlab="Time Months", ylab="Survival probability", lwd=2)
legend("topright", legend=c("BRCA1 Mutation", "Non-mutated"), col=c("red","black"), lwd=2)

# BRCA2 유전자 돌연변이에 따른 생존분석
# Log Rank Test
survdiff( Surv(Time, Status=="DECEASED") ~ BRCA2, data=Data)
res <- coxph(Surv(Time, Status=="DECEASED") ~ BRCA2, data=Data)
summary(res)

fit <- survfit(Surv(Time, Status=="DECEASED") ~ BRCA2, data=Data)
plot(fit, col=c("black","red"), xlab="Time Months", ylab="Survival probability", lwd=2)
legend("topright", legend=c("BRCA2 Mutation", "Non-mutated"), col=c("red","black"), lwd=2)


BRCA <- factor(BRCA1 + BRCA2*2) #0=Non-mutated, 1=BRCA1 Mutated, 2=BRCA2 Mutated, 3=BRCA1 & BRCA2 mutated.
res <- coxph(Surv(Time, Status=="DECEASED") ~ BRCA, data=Data)
summary(res)

fit <- survfit(Surv(Time, Status=="DECEASED") ~ BRCA, data=Data)
plot(fit, col=1:4, xlab="Time Months", ylab="Survival probability", lwd=2)
legend("topright", legend=c("Non-mutated", "BRCA1 Mutation", "BRCA2 Mutation", "BRCA1 & BRCA2 Mutation"), col=1:4, lwd=2)


fit <- survfit(Surv(Time, Status=="DECEASED") ~ BRCA!=0, data=Data)
plot(fit, col=c("black","red"), xlab="Time Months", ylab="Survival probability", lwd=2)
legend("topright", legend=c("BRCA Mutation","Non-mutated"), col=c("red", "black"), lwd=2)


res <- coxph(Surv(Time, Status=="DECEASED") ~ BRCA==0, data=Data)
summary(res)
