kyphosis <- read.table("07.kyphosis.txt", header=T)

# Decision tree 구축하기
fit <- rpart(Kyphosis ~ Age + Number + Start, method="class", data=kyphosis)

# 구성된 의사결정나무 시각화
plot(fit, uniform=TRUE, main="Classification Tree for Kyphosis")
text(fit, use.n=TRUE, all=TRUE, cex=.8)

#구축된 의사결정 나무의 component 확인하기
printcp(fit)

plotcp(fit) # visualize cross-validation results 
summary(fit) # detailed summary of splits


# 구성된 의사결정나무를 이용한 예측
p <- predict(fit, kyphosis)

# AUC값과 ROC curve를 그리기 위한 코드
pr <- prediction(p[,2], kyphosis$Kyphosis == "present")
prf <- performance(pr, measure = "tpr", x.measure = "fpr")

auc_ROCR <- performance(pr, measure = "auc")
auc_ROCR <- round(auc_ROCR@y.values[[1]], 3)

# ROC Curve 그래프 그리기
plot(prf, colorize = T, main=paste0("ROC curve. AUC: ",auc_ROCR))
abline(a = 0, b = 1)


# prune the tree 
pfit<- prune(fit, cp= fit$cptable[which.min(fit$cptable[,"xerror"]),"CP"])

# plot the pruned tree 

plot(pfit, uniform=TRUE, main="Pruned Classification Tree for Kyphosis")
text(pfit, use.n=TRUE, all=TRUE, cex=.8)

p <- predict(pfit, kyphosis)
pr <- prediction(p[,2], kyphosis$Kyphosis == "present")
prf <- performance(pr, measure = "tpr", x.measure = "fpr")

auc_ROCR <- performance(pr, measure = "auc")
auc_ROCR <- round(auc_ROCR@y.values[[1]], 3)

# ROC Curve 그래프 그리기
plot(prf, colorize = T, main=paste0("ROC curve. AUC: ",auc_ROCR))
abline(a = 0, b = 1)


###################	
library(dplyr)
library(tidytext)
library(janeaustenr)
library(tidyr)
library(igraph)
library(ggraph)


austen_bigrams <- austen_books() %>%
  unnest_tokens(bigram, text, token = "ngrams", n = 2)

#데이터 출력
austen_bigrams


#단어 카운팅
austen_bigrams %>% count(bigram, sort = TRUE)

bigrams_separated <- austen_bigrams %>%
 separate(bigram, c("word1", "word2"), sep = " ")

bigrams_filtered <- bigrams_separated %>%
  filter(!word1 %in% stop_words$word) %>%
  filter(!word2 %in% stop_words$word)

# new bigram counts:
bigram_counts <- bigrams_filtered %>% 
  count(word1, word2, sort = TRUE)

bigram_counts

########

  
bigram_graph <- bigram_counts %>%
  filter(n > 20) %>%
  graph_from_data_frame()

bigram_graph

#not words
AFINN <- get_sentiments("afinn")
not_words <- bigrams_separated %>%
  filter(word1 == "not") %>%
  inner_join(AFINN, by = c(word2 = "word")) %>%
  count(word2, score, sort = TRUE) %>%
  ungroup()

not_words

not_words %>%
  mutate(contribution = n * score) %>%
  arrange(desc(abs(contribution))) %>%
  head(20) %>%
  mutate(word2 = reorder(word2, contribution)) %>%
  ggplot(aes(word2, n * score, fill = n * score > 0)) +
  geom_col(show.legend = FALSE) +
  xlab("Words preceded by \"not\"") +
  ylab("Sentiment score * number of occurrences") +
  coord_flip()
#
ggraph(bigram_graph, layout = "fr") +
  geom_edge_link() +
  geom_node_point() +
  geom_node_text(aes(label = name), vjust = 1, hjust = 1)

arrow <- grid::arrow(type = "closed", length = unit(.15, "inches"))

ggraph(bigram_graph, layout = "fr") +
  geom_edge_link(aes(edge_alpha = n), show.legend = FALSE,
                 arrow = arrow, end_cap = circle(.3, 'inches')) +
  geom_node_point(color = "blue", size = 5) +
  geom_node_text(aes(label = name), vjust = 1, hjust = 1) +
  theme_void()
  
  
library(wordcloud)
wordcloud(austen_bigrams$bigram, min.freq = 5,
 colors=brewer.pal(8, "Dark2"), random.order=FALSE)

a <- read.delim("kakaotalk.txt", sep=" ", header=F, stringsAsFactors=F, fileEncoding="euc-kr")
wordcloud(unlist(a), min.freq = 5, colors=brewer.pal(8, "Dark2"), random.order=FALSE)
wordcloud(words = d$word, freq = d$freq, min.freq = 1,
          max.words=200, , rot.per=0.35, 
          )